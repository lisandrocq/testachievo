<?php

// Default width for all graphs
$config['graph_width']=750;

?>