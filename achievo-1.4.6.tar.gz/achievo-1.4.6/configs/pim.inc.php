<?php

// default url to redirect to when the pim is called
$config['pim_redirect_to']='';

// Array with disallowed pim items
$config['disallowedpimitems']=array();
