<?php

/**
 * With this config you can choose to show the employees age
 */
$config['birthday_show_age'] = false;